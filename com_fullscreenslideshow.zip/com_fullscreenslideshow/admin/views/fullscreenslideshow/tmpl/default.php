<?php
// No direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.tooltip');


echo '<h2>Joomgallery Category ID currently selected: ' . $this -> category_id . '</h2>';

echo '<p>To edit the category please click "Options" button.</p>';

?>


