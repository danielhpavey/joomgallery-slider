<?php
defined( '_JEXEC' ) or die;

?>
<ul class = "slides" data-path="<?php echo JURI::base(); ?>">
<li style = "background-image:url('<?php echo $images;?>')" class = "current fish"></li>
</ul>
