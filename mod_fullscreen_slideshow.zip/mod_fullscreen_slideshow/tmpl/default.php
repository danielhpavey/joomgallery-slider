<?php
defined( '_JEXEC' ) or die;
?>
<ul class = "slides">
<li style = "background-image:url('<?php echo $images[0];?>')" class = "current fish"></li>
</ul>
